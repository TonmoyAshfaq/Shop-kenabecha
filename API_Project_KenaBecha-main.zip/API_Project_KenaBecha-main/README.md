# API_Project_KenaBecha


## How to run this app :
First check if node js in your pc or not. If not download and install.
First downlaod the project from this repository. Then open the project any editior(vscode is recomended). Then onpen the terminal and type npm init and hit enter. Then some libraries should 
be installed. So type "npm i express mogoose jsonwebtoken nodemon ejs crypto-js dotenv body-parser axios" and hit enter. the open terminal in vscoode. Make two terminal open.
On the first terminal go to the right directory by typint " cd Bank_API" and hit enter. Then just run with "npm star" .On the second terminal type "cd E-commerce_Api" then hit enter.
After that run "npm start" hit enter. Two localhost will run in two terminal and a link will show in the termial. Just click the link the site will open. 
